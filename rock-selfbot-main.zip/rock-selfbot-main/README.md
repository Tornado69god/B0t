# Rock-Selfbot 1.0

This project demonstrates the usage of a Discord selfbot using discord.js-selfbot-v13 library. It includes various commands such as fetching cryptocurrency prices, checking user balances, sending messages with custom styles, and more. 
# I am not responsible for any harm or damage caused by the usage of this Discord selfbot.
Setup Instructions:
1. Clone the repository to your local machine.
2. Install the required dependencies using npm install.
3. Update the config.js file with your Discord bot token and prefix.
4. Run the bot using node index.js.

🚀 **Help - Available Commands** 🚀

- **addy**: 🔑 Sends your Litecoin (LTC) wallet address in a styled message with emojis.
- **avatar**: Displays the avatar of the mentioned user.
- **bal**: 🔍 Checks the balance of a Litecoin (LTC) wallet address and its equivalent in USD and INR.
- **ban**: Bans a user from the server.
- **banner**: Displays the banner of the user.
- **c2i**: Converts an amount from USD to INR.
- **clear**: Delete messages off a channel
- **gayrate**: Rates how gay a user is.
- **gitsearch**: Searches GitHub for repositories.
- **gituser**: Retrieves information about a GitHub user.
- **guildicon**: Displays the guild icon.
- **hack**: Simulates a prank hack.
- **help**: Displays a list of available commands.
- **i2c**: Converts an amount from INR to USD.
- **iplookup**: Lookup information about an IP address.
- **kick**: Kicks a user from the server.
- **loverate**: Rates the compatibility of two mentioned users as lovers.
- **ltcprice**: 📈 Fetches the current price of Litecoin (LTC).
- **math**: Evaluates a mathematical expression.
- **setnickname**: Changes your own nickname.
- **ping**: Checks the bot's latency.
- **serverinfo**: Displays information about the server.
- **spam**: Spams a message multiple times.
- **status**: Sets the bot's status.
- **upi**: 💳 Pay Here (UPI) ID along with an image in a styled message with emojis.

# 👨‍💻 *Created by devrock*

# Feel free to contribute to this project by submitting pull requests or reporting issues.


# This project is licensed under the MIT License. See the LICENSE file for details.

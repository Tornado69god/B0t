// config.js
module.exports = {
    token: "Your_Token",
    prefix: "!",
    allowedUserIDs: ['yourid1', 'yourid2', 'yourid3']
};
